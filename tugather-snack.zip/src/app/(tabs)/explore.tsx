
import React, { useMemo, useState } from "react";
import {
  View,
  Text,
  TextInput,
  ScrollView,
  Image,
  TouchableOpacity,
  StyleSheet,
  StatusBar,
} from "react-native";
import { router } from "expo-router";
import {
  events,
  type Campus,
  type Category,
} from "../../data/events";

const campuses = ["All", "Rangsit", "Tha Prachan"] as const;

const categories = [
  "All",
  "Music",
  "Workshop",
  "Volunteer",
  "Sports",
] as const;

export default function ExploreScreen() {
  const [search, setSearch] = useState("");

  const [campus, setCampus] = useState<Campus | "All">("All");

  const [category, setCategory] =
    useState<Category | "All">("All");

  const filteredEvents = useMemo(() => {
    const keyword = search.trim().toLowerCase();

    return events.filter((event) => {
      const matchesSearch =
        event.title.toLowerCase().includes(keyword) ||
        event.club.toLowerCase().includes(keyword) ||
        event.category.toLowerCase().includes(keyword);

      const matchesCampus =
        campus === "All" || event.campus === campus;

      const matchesCategory =
        category === "All" || event.category === category;

      return matchesSearch && matchesCampus && matchesCategory;
    });
  }, [search, campus, category]);

  function openEvent(id: string) {
    router.push({
      pathname: "/event/[id]",
      params: { id },
    });
  }

  function resetFilters() {
    setSearch("");
    setCampus("All");
    setCategory("All");
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" />

      <ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={styles.content}
      >
        {/* HEADER */}
        <View style={styles.header}>
          <Text style={styles.logo}>
            <Text style={styles.red}>TU</Text>Gather
          </Text>

          <Text style={styles.edition}>
            THE CAMPUS EDITION
          </Text>
        </View>

        {/* TITLE */}
        <Text style={styles.eyebrow}>
          02 / DISCOVER YOUR CAMPUS
        </Text>

        <Text style={styles.title}>
          Find your{"\n"}
          <Text style={styles.italic}>next thing.</Text>
        </Text>

        <Text style={styles.subtitle}>
          Explore events, meet communities, and discover
          experiences worth showing up for.
        </Text>

        {/* SEARCH */}
        <View style={styles.searchBox}>
          <Text style={styles.searchIcon}>⌕</Text>

          <TextInput
            style={styles.searchInput}
            placeholder="Search events or clubs..."
            placeholderTextColor="#999999"
            value={search}
            onChangeText={setSearch}
            autoCapitalize="none"
            returnKeyType="search"
          />
        </View>

        {/* CAMPUS FILTER */}
        <Text style={styles.filterLabel}>CAMPUS</Text>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filterRow}
        >
          {campuses.map((item) => {
            const active = campus === item;

            return (
              <TouchableOpacity
                key={item}
                onPress={() => setCampus(item)}
                style={[
                  styles.filterButton,
                  active && styles.filterActive,
                ]}
              >
                <Text
                  style={[
                    styles.filterText,
                    active && styles.filterTextActive,
                  ]}
                >
                  {item}
                </Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        {/* CATEGORY FILTER */}
        <Text style={styles.filterLabel}>CATEGORY</Text>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filterRow}
        >
          {categories.map((item) => {
            const active = category === item;

            return (
              <TouchableOpacity
                key={item}
                onPress={() => setCategory(item)}
                style={[
                  styles.filterButton,
                  active && styles.filterActive,
                ]}
              >
                <Text
                  style={[
                    styles.filterText,
                    active && styles.filterTextActive,
                  ]}
                >
                  {item}
                </Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        {/* RESULTS HEADER */}
        <View style={styles.resultsHeader}>
          <Text style={styles.resultsTitle}>
            THE EVENT EDIT
          </Text>

          <Text style={styles.resultsCount}>
            {filteredEvents.length} EVENTS
          </Text>
        </View>

        {/* EVENT LIST */}
        {filteredEvents.length === 0 ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyTitle}>
              Nothing found.
            </Text>

            <Text style={styles.emptyDescription}>
              Try another search or change your filters.
            </Text>

            <TouchableOpacity onPress={resetFilters}>
              <Text style={styles.resetText}>
                RESET FILTERS →
              </Text>
            </TouchableOpacity>
          </View>
        ) : (
          filteredEvents.map((event, index) => (
            <TouchableOpacity
              key={event.id}
              style={styles.eventCard}
              activeOpacity={0.85}
              onPress={() => openEvent(event.id)}
            >
              <Image
                source={{ uri: event.image }}
                style={styles.eventImage}
                resizeMode="cover"
              />

              <View style={styles.eventInfo}>
                <View style={styles.eventTopRow}>
                  <Text style={styles.eventCategory}>
                    {event.category.toUpperCase()}
                  </Text>

                  <Text style={styles.eventNumber}>
                    NO. {String(index + 1).padStart(2, "0")}
                  </Text>
                </View>

                <Text style={styles.eventTitle}>
                  {event.title}
                </Text>

                <Text style={styles.clubName}>
                  BY {event.club.toUpperCase()}
                </Text>

                <View style={styles.eventFooter}>
                  <View>
                    <Text style={styles.eventDate}>
                      {event.date}
                    </Text>

                    <Text style={styles.eventCampus}>
                      {event.campus.toUpperCase()}
                    </Text>
                  </View>

                  <Text style={styles.eventArrow}>↗</Text>
                </View>
              </View>
            </TouchableOpacity>
          ))
        )}

        <Text style={styles.footer}>
          DISCOVER MORE. EXPERIENCE MORE.
        </Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8F6F1",
  },

  content: {
    paddingHorizontal: 24,
    paddingTop: 55,
    paddingBottom: 40,
  },

  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 35,
  },

  logo: {
    fontSize: 25,
    fontWeight: "900",
    color: "#171717",
    letterSpacing: -1,
  },

  red: {
    color: "#B5122D",
  },

  edition: {
    fontSize: 9,
    color: "#888888",
    fontWeight: "700",
    letterSpacing: 1,
  },

  eyebrow: {
    color: "#B5122D",
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1.6,
    marginBottom: 15,
  },

  title: {
    fontSize: 49,
    fontWeight: "800",
    color: "#171717",
    letterSpacing: -1.8,
    lineHeight: 54,
  },

  italic: {
    fontStyle: "italic",
    fontWeight: "400",
  },

  subtitle: {
    fontSize: 13,
    color: "#777777",
    lineHeight: 21,
    marginTop: 16,
    marginBottom: 28,
  },

  searchBox: {
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#DDD8D0",
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    height: 55,
    marginBottom: 28,
  },

  searchIcon: {
    fontSize: 27,
    color: "#B5122D",
    marginRight: 12,
  },

  searchInput: {
    flex: 1,
    fontSize: 14,
    color: "#171717",
  },

  filterLabel: {
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1.5,
    color: "#171717",
    marginBottom: 12,
  },

  filterRow: {
    gap: 8,
    paddingBottom: 25,
  },

  filterButton: {
    paddingHorizontal: 17,
    paddingVertical: 11,
    borderWidth: 1,
    borderColor: "#D8D3CA",
    backgroundColor: "transparent",
  },

  filterActive: {
    backgroundColor: "#171717",
    borderColor: "#171717",
  },

  filterText: {
    fontSize: 12,
    fontWeight: "600",
    color: "#666666",
  },

  filterTextActive: {
    color: "#FFFFFF",
  },

  resultsHeader: {
    borderTopWidth: 1,
    borderTopColor: "#171717",
    paddingTop: 17,
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 24,
  },

  resultsTitle: {
    fontSize: 12,
    fontWeight: "900",
    letterSpacing: 1.5,
    color: "#171717",
  },

  resultsCount: {
    fontSize: 10,
    color: "#B5122D",
    fontWeight: "800",
  },

  eventCard: {
    backgroundColor: "#FFFFFF",
    marginBottom: 24,
  },

  eventImage: {
    width: "100%",
    height: 195,
    backgroundColor: "#E5E0D8",
  },

  eventInfo: {
    padding: 19,
  },

  eventTopRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },

  eventCategory: {
    fontSize: 10,
    color: "#B5122D",
    fontWeight: "800",
    letterSpacing: 1.1,
  },

  eventNumber: {
    fontSize: 10,
    color: "#999999",
    fontWeight: "700",
  },

  eventTitle: {
    fontSize: 26,
    fontWeight: "800",
    color: "#171717",
    marginTop: 12,
    letterSpacing: -0.7,
  },

  clubName: {
    fontSize: 10,
    color: "#888888",
    fontWeight: "700",
    letterSpacing: 0.8,
    marginTop: 10,
  },

  eventFooter: {
    borderTopWidth: 1,
    borderTopColor: "#EEEAE4",
    paddingTop: 16,
    marginTop: 20,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  eventDate: {
    fontSize: 11,
    fontWeight: "800",
    color: "#171717",
  },

  eventCampus: {
    fontSize: 10,
    color: "#888888",
    marginTop: 5,
  },

  eventArrow: {
    fontSize: 29,
    color: "#B5122D",
  },

  emptyState: {
    paddingVertical: 55,
    alignItems: "center",
  },

  emptyTitle: {
    fontSize: 29,
    fontWeight: "800",
    color: "#171717",
  },

  emptyDescription: {
    fontSize: 13,
    color: "#888888",
    marginTop: 12,
    textAlign: "center",
  },

  resetText: {
    color: "#B5122D",
    fontSize: 12,
    fontWeight: "800",
    marginTop: 24,
  },

  footer: {
    textAlign: "center",
    fontSize: 10,
    color: "#999999",
    letterSpacing: 1.2,
    marginTop: 20,
  },
});
