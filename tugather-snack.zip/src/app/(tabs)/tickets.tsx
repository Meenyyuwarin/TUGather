
import { View, Text, StyleSheet } from "react-native";

export default function TicketsScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.label}>03 / YOUR EXPERIENCES</Text>
      <Text style={styles.title}>My Tickets.</Text>
      <Text style={styles.description}>
        กิจกรรมที่ลงทะเบียนไว้จะแสดงที่นี่
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8F6F1",
    paddingHorizontal: 24,
    paddingTop: 80,
  },
  label: {
    fontSize: 11,
    color: "#B5122D",
    fontWeight: "800",
    letterSpacing: 2,
  },
  title: {
    fontSize: 48,
    fontWeight: "800",
    color: "#171717",
    marginTop: 20,
  },
  description: {
    color: "#777",
    fontSize: 14,
    marginTop: 12,
  },
});
