
import React from "react";
import {
  View,
  Text,
  ScrollView,
  Image,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import { router } from "expo-router";

const events = [
  {
    id: "1",
    title: "TU Music Festival",
    category: "MUSIC & ENTERTAINMENT",
    date: "20 OCT 2026",
    campus: "RANGSIT",
    image: "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=800",
  },
  {
    id: "2",
    title: "Creative Art Workshop",
    category: "ART & CULTURE",
    date: "24 OCT 2026",
    campus: "THA PRACHAN",
    image: "https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=800",
  },
];

export default function HomeScreen() {
  return (
    <View style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={styles.logo}>
            <Text style={styles.red}>TU</Text>Gather
          </Text>
          <Text style={styles.headerRight}>THE CAMPUS EDITION</Text>
        </View>

        <View style={styles.intro}>
          <Text style={styles.eyebrow}>THE CAMPUS EDITION / 2026</Text>
          <Text style={styles.title}>
            What&apos;s{"\n"}
            <Text style={styles.italic}>happening?</Text>
          </Text>
          <Text style={styles.subtitle}>
            Discover events, connect with communities,
            and make every campus moment count.
          </Text>
        </View>

        <View style={styles.sectionRow}>
          <Text style={styles.sectionLabel}>01 / FEATURED EVENT</Text>
          <Text style={styles.sectionLink}>THIS WEEK</Text>
        </View>

        <TouchableOpacity
          style={styles.featuredCard}
          onPress={() => router.push("/(tabs)/explore")}
        >
          <Image
            source={{ uri: events[0].image }}
            style={styles.featuredImage}
          />

          <View style={styles.featuredInfo}>
            <Text style={styles.category}>{events[0].category}</Text>
            <Text style={styles.featuredTitle}>{events[0].title}</Text>
            <Text style={styles.meta}>
              {events[0].date} / {events[0].campus}
            </Text>

            <Text style={styles.viewEvent}>EXPLORE EVENTS →</Text>
          </View>
        </TouchableOpacity>

        <View style={styles.sectionRow}>
          <Text style={styles.sectionLabel}>02 / DISCOVER MORE</Text>
          <TouchableOpacity onPress={() => router.push("/(tabs)/explore")}>
            <Text style={styles.sectionLink}>VIEW ALL →</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.discoverTitle}>
          Find your{"\n"}next thing.
        </Text>

        {events.map((event, index) => (
          <TouchableOpacity
            key={event.id}
            style={styles.eventRow}
            onPress={() => router.push("/(tabs)/explore")}
          >
            <Text style={styles.eventNumber}>0{index + 1}</Text>

            <View style={styles.eventText}>
              <Text style={styles.category}>{event.category}</Text>
              <Text style={styles.eventTitle}>{event.title}</Text>
              <Text style={styles.meta}>
                {event.date} / {event.campus}
              </Text>
            </View>

            <Text style={styles.arrow}>→</Text>
          </TouchableOpacity>
        ))}

        <Text style={styles.footer}>MADE FOR THE TU COMMUNITY.</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8F6F1",
  },
  header: {
    paddingHorizontal: 24,
    paddingTop: 55,
    paddingBottom: 24,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  logo: {
    fontSize: 27,
    fontWeight: "900",
    letterSpacing: -1.5,
    color: "#171717",
  },
  red: {
    color: "#B5122D",
  },
  headerRight: {
    fontSize: 9,
    color: "#888",
    fontWeight: "700",
    letterSpacing: 1,
  },
  intro: {
    paddingHorizontal: 24,
    marginBottom: 35,
  },
  eyebrow: {
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1.7,
    color: "#B5122D",
    marginBottom: 16,
  },
  title: {
    fontSize: 53,
    fontWeight: "800",
    letterSpacing: -2,
    lineHeight: 57,
    color: "#171717",
  },
  italic: {
    fontStyle: "italic",
    fontWeight: "400",
  },
  subtitle: {
    fontSize: 13,
    color: "#777",
    lineHeight: 22,
    marginTop: 18,
  },
  sectionRow: {
    paddingHorizontal: 24,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 17,
  },
  sectionLabel: {
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1.3,
    color: "#B5122D",
  },
  sectionLink: {
    fontSize: 10,
    fontWeight: "700",
    color: "#777",
  },
  featuredCard: {
    marginHorizontal: 24,
    backgroundColor: "#FFF",
    marginBottom: 40,
  },
  featuredImage: {
    width: "100%",
    height: 230,
  },
  featuredInfo: {
    padding: 20,
  },
  category: {
    fontSize: 10,
    fontWeight: "700",
    letterSpacing: 1.2,
    color: "#B5122D",
  },
  featuredTitle: {
    fontSize: 27,
    fontWeight: "800",
    color: "#171717",
    marginTop: 10,
  },
  meta: {
    fontSize: 10,
    color: "#888",
    letterSpacing: 0.7,
    marginTop: 10,
  },
  viewEvent: {
    color: "#B5122D",
    fontSize: 11,
    fontWeight: "800",
    marginTop: 22,
  },
  discoverTitle: {
    fontSize: 37,
    fontWeight: "800",
    letterSpacing: -1,
    lineHeight: 42,
    color: "#171717",
    paddingHorizontal: 24,
    marginBottom: 24,
  },
  eventRow: {
    flexDirection: "row",
    alignItems: "center",
    marginHorizontal: 24,
    paddingVertical: 22,
    borderTopWidth: 1,
    borderColor: "#DDD8D0",
  },
  eventNumber: {
    width: 42,
    color: "#B5122D",
    fontSize: 14,
    fontWeight: "800",
  },
  eventText: {
    flex: 1,
  },
  eventTitle: {
    fontSize: 18,
    fontWeight: "800",
    color: "#171717",
    marginTop: 6,
  },
  arrow: {
    fontSize: 22,
    color: "#171717",
  },
  footer: {
    textAlign: "center",
    paddingVertical: 35,
    fontSize: 10,
    color: "#999",
    letterSpacing: 1.5,
  },
});
