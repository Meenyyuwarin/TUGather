
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import { router } from "expo-router";

export default function ProfileScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.label}>04 / ACCOUNT</Text>
      <Text style={styles.title}>Your Profile.</Text>
      <Text style={styles.description}>
        Manage your account, clubs, and activities.
      </Text>

      <TouchableOpacity
        style={styles.button}
        onPress={() => router.push("/login")}
      >
        <Text style={styles.buttonText}>SIGN IN / REGISTER →</Text>
      </TouchableOpacity>

      <Text style={styles.note}>
        Club management will be added in a later phase.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8F6F1",
    paddingHorizontal: 24,
    paddingTop: 80,
  },
  label: {
    fontSize: 11,
    color: "#B5122D",
    fontWeight: "800",
    letterSpacing: 2,
  },
  title: {
    fontSize: 44,
    fontWeight: "800",
    color: "#171717",
    marginTop: 20,
  },
  description: {
    color: "#777",
    fontSize: 14,
    marginTop: 12,
  },
  button: {
    marginTop: 35,
    padding: 18,
    backgroundColor: "#B5122D",
    borderRadius: 4,
  },
  buttonText: {
    color: "#FFF",
    fontWeight: "800",
    textAlign: "center",
  },
  note: {
    fontSize: 12,
    color: "#999",
    marginTop: 18,
  },
});
