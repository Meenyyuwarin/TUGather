
import React from "react";
import {
  View,
  Text,
  ScrollView,
  Image,
  TouchableOpacity,
  StyleSheet,
  StatusBar,
} from "react-native";
import { router } from "expo-router";

export default function WelcomeScreen() {
  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" />

      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Text style={styles.logo}>
            <Text style={styles.red}>TU</Text>Gather
          </Text>
          <Text style={styles.edition}>THE CAMPUS EDITION</Text>
        </View>

        <Image
          source={{
            uri: "https://images.unsplash.com/photo-1562774053-701939374585?w=1000",
          }}
          style={styles.hero}
        />

        <Text style={styles.eyebrow}>
          NO. 001 / THE BEGINNING
        </Text>

        <Text style={styles.title}>
          Your campus.{"\n"}
          <Text style={styles.italic}>Your world.</Text>
        </Text>

        <Text style={styles.description}>
          Discover events, connect with communities,
          and make every campus moment count.
        </Text>

        <Text style={styles.thaiDescription}>
          ค้นพบกิจกรรมใหม่ ๆ พบปะผู้คน และเป็นส่วนหนึ่ง
          ของคอมมูนิตี้ที่ใช่สำหรับคุณ
        </Text>

        <View style={styles.buttons}>
          <TouchableOpacity
            style={styles.googleButton}
            onPress={() => router.push("/login")}
          >
            <Text style={styles.darkButtonText}>
              Continue with Google
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.appleButton}
            onPress={() => router.push("/login")}
          >
            <Text style={styles.whiteButtonText}>
              Continue with Apple
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.emailButton}
            onPress={() => router.push("/login")}
          >
            <Text style={styles.redButtonText}>
              Continue with Email
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.guestButton}
            onPress={() => router.replace("/(tabs)")}
          >
            <Text style={styles.guestText}>
              Explore as Guest →
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8F6F1",
  },
  content: {
    paddingHorizontal: 24,
    paddingTop: 58,
    paddingBottom: 32,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 24,
  },
  logo: {
    fontSize: 25,
    fontWeight: "900",
    color: "#171717",
    letterSpacing: -1,
  },
  red: {
    color: "#B5122D",
  },
  edition: {
    fontSize: 9,
    fontWeight: "700",
    letterSpacing: 1.1,
    color: "#888",
  },
  hero: {
    width: "100%",
    height: 220,
    borderRadius: 3,
    marginBottom: 26,
  },
  eyebrow: {
    fontSize: 10,
    fontWeight: "800",
    color: "#B5122D",
    letterSpacing: 1.7,
    marginBottom: 16,
  },
  title: {
    fontSize: 43,
    fontWeight: "800",
    color: "#171717",
    letterSpacing: -1.8,
    lineHeight: 50,
  },
  italic: {
    fontStyle: "italic",
    fontWeight: "400",
  },
  description: {
    color: "#666",
    fontSize: 13,
    lineHeight: 21,
    marginTop: 18,
  },
  thaiDescription: {
    color: "#888",
    fontSize: 12,
    lineHeight: 20,
    marginTop: 12,
  },
  buttons: {
    marginTop: 30,
    gap: 10,
  },
  googleButton: {
    backgroundColor: "#FFF",
    borderWidth: 1,
    borderColor: "#DDD",
    padding: 17,
    borderRadius: 4,
  },
  appleButton: {
    backgroundColor: "#171717",
    padding: 17,
    borderRadius: 4,
  },
  emailButton: {
    borderWidth: 1,
    borderColor: "#B5122D",
    padding: 17,
    borderRadius: 4,
  },
  darkButtonText: {
    color: "#171717",
    textAlign: "center",
    fontWeight: "700",
  },
  whiteButtonText: {
    color: "#FFF",
    textAlign: "center",
    fontWeight: "700",
  },
  redButtonText: {
    color: "#B5122D",
    textAlign: "center",
    fontWeight: "700",
  },
  guestButton: {
    alignItems: "center",
    padding: 15,
  },
  guestText: {
    color: "#B5122D",
    fontSize: 12,
    fontWeight: "800",
  },
});
