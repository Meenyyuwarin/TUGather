
import React, { useState } from "react";
import {
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from "react-native";
import { router } from "expo-router";

export default function LoginScreen() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  function handleDemoLogin() {
    if (!email.trim() || !password.trim()) {
      Alert.alert("Missing information", "Please enter your email and password.");
      return;
    }

    Alert.alert(
      "Demo Mode",
      "This is a UI demo. Authentication is not connected yet.",
      [
        {
          text: "Continue",
          onPress: () => router.replace("/(tabs)"),
        },
      ]
    );
  }

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <TouchableOpacity onPress={() => router.back()}>
        <Text style={styles.back}>← BACK</Text>
      </TouchableOpacity>

      <Text style={styles.eyebrow}>YOUR CAMPUS ACCOUNT</Text>

      <Text style={styles.title}>
        Welcome{"\n"}
        <Text style={styles.italic}>back.</Text>
      </Text>

      <Text style={styles.subtitle}>
        Sign in to discover and join campus experiences.
      </Text>

      <Text style={styles.label}>EMAIL ADDRESS</Text>
      <TextInput
        style={styles.input}
        placeholder="you@example.com"
        placeholderTextColor="#999"
        autoCapitalize="none"
        keyboardType="email-address"
        value={email}
        onChangeText={setEmail}
      />

      <Text style={styles.label}>PASSWORD</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter your password"
        placeholderTextColor="#999"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />

      <TouchableOpacity
        style={styles.button}
        onPress={handleDemoLogin}
      >
        <Text style={styles.buttonText}>CONTINUE →</Text>
      </TouchableOpacity>

      <Text style={styles.note}>
        Demo only — no account is created or verified.
      </Text>

      <TouchableOpacity onPress={() => router.replace("/(tabs)")}>
        <Text style={styles.guest}>Explore without signing in →</Text>
      </TouchableOpacity>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8F6F1",
    paddingHorizontal: 28,
    paddingTop: 75,
  },
  back: {
    fontSize: 12,
    fontWeight: "800",
    color: "#B5122D",
    marginBottom: 55,
  },
  eyebrow: {
    fontSize: 10,
    fontWeight: "800",
    color: "#B5122D",
    letterSpacing: 2,
  },
  title: {
    fontSize: 56,
    fontWeight: "800",
    color: "#171717",
    lineHeight: 62,
    marginTop: 16,
  },
  italic: {
    fontStyle: "italic",
    fontWeight: "400",
  },
  subtitle: {
    fontSize: 14,
    color: "#777",
    marginTop: 20,
    marginBottom: 40,
    lineHeight: 22,
  },
  label: {
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1.4,
    color: "#171717",
    marginBottom: 10,
  },
  input: {
    borderWidth: 1,
    borderColor: "#DDD8D0",
    backgroundColor: "#FFF",
    padding: 17,
    borderRadius: 4,
    fontSize: 14,
    marginBottom: 24,
    color: "#171717",
  },
  button: {
    backgroundColor: "#B5122D",
    padding: 19,
    borderRadius: 4,
    marginTop: 10,
  },
  buttonText: {
    textAlign: "center",
    color: "#FFF",
    fontWeight: "800",
    letterSpacing: 1,
  },
  note: {
    textAlign: "center",
    fontSize: 11,
    color: "#999",
    marginTop: 18,
  },
  guest: {
    textAlign: "center",
    color: "#B5122D",
    fontWeight: "700",
    marginTop: 30,
  },
});
