
import React from "react";
import {
  View,
  Text,
  Image,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { events } from "../../data/events";

export default function EventDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();

  const event = events.find((item) => item.id === id);

  if (!event) {
    return (
      <View style={styles.notFound}>
        <Text style={styles.title}>Event not found.</Text>
        <TouchableOpacity onPress={() => router.back()}>
          <Text style={styles.backText}>← GO BACK</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const availableSeats = event.capacity - event.registered;
  const isFull = availableSeats <= 0;

  function handleRegister() {
    Alert.alert(
      "Registration Preview",
      "Registration is not connected yet. We will build the registration and ticket system next.",
      [{ text: "OK" }]
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <Text style={styles.backText}>← BACK TO EXPLORE</Text>
        </TouchableOpacity>

        <View style={styles.headerRow}>
          <Text style={styles.logo}>
            <Text style={styles.red}>TU</Text>Gather
          </Text>
          <Text style={styles.edition}>THE CAMPUS EDITION</Text>
        </View>

        <Image
          source={{ uri: event.image }}
          style={styles.heroImage}
          resizeMode="cover"
        />

        <View style={styles.body}>
          <Text style={styles.eyebrow}>
            {event.category.toUpperCase()} / {event.campus.toUpperCase()}
          </Text>

          <Text style={styles.title}>{event.title}</Text>

          <Text style={styles.host}>
            HOSTED BY {event.club.toUpperCase()}
          </Text>

          <View style={styles.divider} />

          <View style={styles.infoGrid}>
            <View style={styles.infoItem}>
              <Text style={styles.infoLabel}>DATE</Text>
              <Text style={styles.infoValue}>{event.date}</Text>
            </View>

            <View style={styles.infoItem}>
              <Text style={styles.infoLabel}>TIME</Text>
              <Text style={styles.infoValue}>{event.time}</Text>
            </View>

            <View style={styles.infoItem}>
              <Text style={styles.infoLabel}>LOCATION</Text>
              <Text style={styles.infoValue}>{event.location}</Text>
            </View>

            <View style={styles.infoItem}>
              <Text style={styles.infoLabel}>AVAILABLE SEATS</Text>
              <Text style={styles.infoValue}>
                {availableSeats} / {event.capacity}
              </Text>
            </View>
          </View>

          <View style={styles.divider} />

          <Text style={styles.sectionNumber}>01 / THE DETAILS</Text>
          <Text style={styles.sectionTitle}>About this event.</Text>

          <Text style={styles.description}>
            {event.description}
          </Text>

          <View style={styles.organizerBox}>
            <Text style={styles.infoLabel}>ORGANIZED BY</Text>
            <Text style={styles.organizerName}>{event.club}</Text>
            <Text style={styles.organizerSubtitle}>
              A TUGather campus community
            </Text>
          </View>

          <Text style={styles.footer}>
            YOUR CAMPUS. YOUR STORY.
          </Text>
        </View>
      </ScrollView>

      <View style={styles.bottomBar}>
        <View>
          <Text style={styles.bottomLabel}>AVAILABILITY</Text>
          <Text style={styles.bottomSeats}>
            {isFull ? "FULLY BOOKED" : `${availableSeats} SEATS LEFT`}
          </Text>
        </View>

        <TouchableOpacity
          style={[
            styles.registerButton,
            isFull && styles.disabledButton,
          ]}
          onPress={handleRegister}
          disabled={isFull}
        >
          <Text style={styles.registerText}>
            {isFull ? "EVENT FULL" : "REGISTER →"}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8F6F1",
  },
  scrollContent: {
    paddingTop: 55,
    paddingBottom: 30,
  },
  backButton: {
    paddingHorizontal: 24,
    marginBottom: 22,
  },
  backText: {
    fontSize: 11,
    fontWeight: "800",
    color: "#B5122D",
    letterSpacing: 1,
  },
  headerRow: {
    paddingHorizontal: 24,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 24,
  },
  logo: {
    fontSize: 25,
    fontWeight: "900",
    color: "#171717",
  },
  red: {
    color: "#B5122D",
  },
  edition: {
    fontSize: 9,
    fontWeight: "700",
    color: "#888",
    letterSpacing: 1,
  },
  heroImage: {
    width: "100%",
    height: 260,
    backgroundColor: "#E5E0D8",
  },
  body: {
    paddingHorizontal: 24,
    paddingTop: 28,
  },
  eyebrow: {
    color: "#B5122D",
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1.3,
    marginBottom: 15,
  },
  title: {
    fontSize: 43,
    fontWeight: "800",
    letterSpacing: -1.5,
    lineHeight: 48,
    color: "#171717",
  },
  host: {
    fontSize: 11,
    color: "#777",
    fontWeight: "700",
    letterSpacing: 0.8,
    marginTop: 16,
  },
  divider: {
    height: 1,
    backgroundColor: "#D8D3CA",
    marginVertical: 28,
  },
  infoGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    rowGap: 26,
  },
  infoItem: {
    width: "50%",
    paddingRight: 10,
  },
  infoLabel: {
    fontSize: 10,
    color: "#999",
    fontWeight: "800",
    letterSpacing: 1,
    marginBottom: 9,
  },
  infoValue: {
    fontSize: 14,
    fontWeight: "800",
    color: "#171717",
  },
  sectionNumber: {
    fontSize: 10,
    color: "#B5122D",
    fontWeight: "800",
    letterSpacing: 1.3,
  },
  sectionTitle: {
    fontSize: 30,
    fontWeight: "800",
    color: "#171717",
    marginTop: 14,
    marginBottom: 18,
  },
  description: {
    fontSize: 14,
    color: "#666",
    lineHeight: 24,
  },
  organizerBox: {
    backgroundColor: "#EEEAE3",
    padding: 22,
    marginTop: 32,
  },
  organizerName: {
    fontSize: 21,
    fontWeight: "800",
    color: "#171717",
    marginTop: 6,
  },
  organizerSubtitle: {
    fontSize: 12,
    color: "#888",
    marginTop: 8,
  },
  footer: {
    fontSize: 10,
    textAlign: "center",
    color: "#AAA",
    letterSpacing: 1.5,
    marginTop: 40,
  },
  bottomBar: {
    backgroundColor: "#FFF",
    borderTopWidth: 1,
    borderTopColor: "#E5E0D8",
    paddingHorizontal: 24,
    paddingVertical: 15,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  bottomLabel: {
    fontSize: 9,
    color: "#888",
    fontWeight: "800",
    letterSpacing: 1,
  },
  bottomSeats: {
    fontSize: 13,
    fontWeight: "800",
    color: "#171717",
    marginTop: 5,
  },
  registerButton: {
    backgroundColor: "#B5122D",
    paddingHorizontal: 26,
    paddingVertical: 17,
  },
  disabledButton: {
    backgroundColor: "#AAA",
  },
  registerText: {
    color: "#FFF",
    fontSize: 12,
    fontWeight: "800",
    letterSpacing: 0.7,
  },
  notFound: {
    flex: 1,
    backgroundColor: "#F8F6F1",
    padding: 30,
    justifyContent: "center",
  },
});
